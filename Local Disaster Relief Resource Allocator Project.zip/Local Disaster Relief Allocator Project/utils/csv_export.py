import csv
from datetime import datetime
from db.queries import get_all_disasters

def export_disasters_to_csv():
    today_str = datetime.now().strftime("%Y-%m-%d")
    filename = f"disaster_export_{today_str}.csv"

    disasters = get_all_disasters()

    with open(filename, mode="w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Disaster ID", "Name", "Type", "Severity", "Latitude", "Longitude", "Date", "Status"])

        for d in disasters:
            status = "fulfilled" if d.get("fulfilled") else "pending"
            writer.writerow([
                d["disaster_id"], d["name"], d["type"], d["severity"],
                d["location_lat"], d["location_lon"], d["report_date"], status
            ])
