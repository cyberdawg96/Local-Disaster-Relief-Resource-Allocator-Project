import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
from utils.auth import authenticate_user
from ui.admin_dashboard import AdminDashboard
from ui.clerk_dashboard import ClerkDashboard
from ui.coordinator_dashboard import CoordinatorDashboard

GRADIENT_PATH = "gradient_bg.png"

class LoginApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Disaster Relief Login")

        window_width = 640
        window_height = 480
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width // 2) - (window_width // 2)
        y = (screen_height // 2) - (window_height // 2)
        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.root.resizable(False, False)

        # Gradient background
        self.bg_image = Image.open(GRADIENT_PATH).resize((640, 480))
        self.bg_photo = ImageTk.PhotoImage(self.bg_image)
        self.bg_label = tk.Label(root, image=self.bg_photo)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)

        self.container = tk.Frame(root, bg="white", bd=1, relief="solid",
                                  highlightbackground="darkgrey", highlightthickness=1)
        self.container.place(relx=0.5, rely=0.5, anchor="center", width=360, height=370)

        self.build_ui()

    def build_ui(self):
        padding = {'padx': 20, 'pady': 10}

        tk.Label(self.container, text="Sign In", font=("Segoe UI", 16, "bold"),
                 bg="white", fg="black").pack(pady=(30, 10))

        tk.Label(self.container, text="Enter Username:", bg="white", fg="black", font=("Segoe UI", 11)).pack(**padding)
        self.username_entry = tk.Entry(self.container, bg="white", fg="black",
                                       font=("Segoe UI", 11), relief="flat",
                                       highlightthickness=1, highlightbackground="black")
        self.username_entry.pack(ipady=6, fill="x", padx=30)

        tk.Label(self.container, text="Enter Password:", bg="white", fg="black", font=("Segoe UI", 11)).pack(**padding)
        self.password_entry = tk.Entry(self.container, bg="white", fg="black",
                                       font=("Segoe UI", 11), show="•", relief="flat",
                                       highlightthickness=1, highlightbackground="black")
        self.password_entry.pack(ipady=6, fill="x", padx=30)

        self.login_btn = tk.Label(self.container, text="Log In", bg="#8B5CF6", fg="white",
                                  font=("Segoe UI", 11, "bold"), cursor="hand2", bd=0, relief="flat")
        self.login_btn.pack(pady=(20, 10), ipady=6, ipadx=10)
        self.login_btn.bind("<Button-1>", self.login)
        self.login_btn.bind("<Enter>", lambda e: self.login_btn.config(bg="#7C3AED"))
        self.login_btn.bind("<Leave>", lambda e: self.login_btn.config(bg="#8B5CF6"))

        tk.Label(self.container, text="Disaster Relief Portal", font=("Segoe UI", 10),
                 bg="white", fg="#585c57").pack(pady=(5, 0))  

    def login(self, event):
        username = self.username_entry.get()
        password = self.password_entry.get()
        user = authenticate_user(username, password)

        if user:
            self.root.withdraw()
            role = user["role"]
            if role == "admin":
                dashboard = tk.Toplevel(self.root)
                AdminDashboard(dashboard, user)
            elif role == "clerk":
                dashboard = tk.Toplevel(self.root)
                ClerkDashboard(dashboard, user)
            elif role == "coordinator":
                dashboard = tk.Toplevel(self.root)
                CoordinatorDashboard(dashboard, user)
        else:
            messagebox.showerror("Login Failed", "Invalid username or password.")

if __name__ == "__main__":
    root = tk.Tk()
    app = LoginApp(root)
    root.mainloop()