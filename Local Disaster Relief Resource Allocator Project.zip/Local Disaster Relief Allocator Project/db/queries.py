import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",           
        password="",   # Rohit Sir, kindly insert your database password here!
        database="disaster_relief_db"
    )

def authenticate_user(username, password):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
    user = cursor.fetchone()
    conn.close()
    return user

def get_all_users():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT username, role FROM users WHERE role != 'admin'")
    users = cursor.fetchall()
    conn.close()
    return users

def add_user(username, password, role):
    if role == 'admin':
        return False
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (username, password, role) VALUES (%s, %s, %s)", (username, password, role))
        conn.commit()
        conn.close()
        return True
    except:
        return False

def delete_user_by_username(username):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users WHERE username=%s AND role != 'admin'", (username,))
        conn.commit()
        conn.close()
        return True
    except:
        return False

def add_disaster(name, dtype, severity, lat, lon, report_date, resource_type, resource_quantity):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO disasters (name, type, severity, location_lat, location_lon, report_date, required_resource_type, required_quantity)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """, (name, dtype, severity, lat, lon, report_date, resource_type, resource_quantity))

    conn.commit()
    conn.close()
    return True

def get_all_disasters():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM disasters")
    disasters = cursor.fetchall()

    for d in disasters:
        d["fulfilled"] = is_disaster_fulfilled(d["disaster_id"])
    conn.close()
    return disasters
def get_disaster_requirements(disaster_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT required_resource_type, required_quantity
        FROM disasters
        WHERE disaster_id = %s
    """, (disaster_id,))
    result = cursor.fetchone()
    conn.close()
    return result  

def is_disaster_fulfilled(disaster_id):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT required_resource_type, required_quantity
            FROM disasters
            WHERE disaster_id = %s
        """, (disaster_id,))
        disaster = cursor.fetchone()
        if not disaster:
            conn.close()
            return False

        rtype = disaster[0]
        rqty = disaster[1]

        cursor.execute("""
            SELECT IFNULL(SUM(a.quantity_allocated), 0)
            FROM allocations a
            JOIN resources r ON r.resource_id = a.resource_id
            WHERE a.disaster_id = %s AND r.type = %s
        """, (disaster_id, rtype))

        allocated = cursor.fetchone()[0]
        conn.close()

        return allocated >= rqty
    except:
        return False

def get_all_coordinators():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT user_id, username FROM users WHERE role='coordinator'")
    data = cursor.fetchall()
    conn.close()
    return data

def assign_disaster_to_coordinator(disaster_id, coordinator_id):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT * FROM coordinator_disaster_assignments
            WHERE disaster_id = %s
        """, (disaster_id,))
        if cursor.fetchone():
            conn.close()
            return False  

        cursor.execute("""
            INSERT INTO coordinator_disaster_assignments (disaster_id, coordinator_id)
            VALUES (%s, %s)
        """, (disaster_id, coordinator_id))
        conn.commit()
        conn.close()
        return True
    except:
        return False
def get_disaster_assigned_count(coordinator_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT COUNT(*) FROM coordinator_disaster_assignments
        WHERE coordinator_id = %s
    """, (coordinator_id,))
    count = cursor.fetchone()[0]
    conn.close()
    return count

def get_disasters_for_coordinator(coordinator_id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT d.*
        FROM disasters d
        JOIN coordinator_disaster_assignments cda ON cda.disaster_id = d.disaster_id
        WHERE cda.coordinator_id = %s
    """, (coordinator_id,))
    data = cursor.fetchall()
    for d in data:
        d["fulfilled"] = is_disaster_fulfilled(d["disaster_id"])
    conn.close()
    return data

def add_resource(type, quantity, unit, lat, lon):
    try:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO resources (type, quantity, unit, current_location_lat, current_location_lon)
            VALUES (%s, %s, %s, %s, %s)
        """, (type, quantity, unit, lat, lon))
        conn.commit()
        conn.close()
        return True
    except:
        return False

def get_available_resources():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM resources WHERE status = 'available'")
    data = cursor.fetchall()
    conn.close()
    return data

def allocate_resource(resource_id, disaster_id, user_id, quantity_allocated, date_allocated):
    try:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT quantity FROM resources WHERE resource_id = %s AND status = 'available' FOR UPDATE", (resource_id,))
        row = cursor.fetchone()
        if not row or row[0] < quantity_allocated:
            conn.close()
            return False

        cursor.execute("""
            INSERT INTO allocations (resource_id, disaster_id, allocated_by, quantity_allocated, allocation_date, delivery_status)
            VALUES (%s, %s, %s, %s, %s, 'pending')
        """, (resource_id, disaster_id, user_id, quantity_allocated, date_allocated))

        remaining = row[0] - quantity_allocated
        if remaining > 0:
            cursor.execute("UPDATE resources SET quantity = %s WHERE resource_id = %s", (remaining, resource_id))
        else:
            cursor.execute("UPDATE resources SET status = 'reserved', quantity = 0 WHERE resource_id = %s", (resource_id,))

        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print("Allocation error:", e)
        return False
def get_allocated_sum(disaster_id, resource_type):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT IFNULL(SUM(a.quantity_allocated), 0)
        FROM allocations a
        JOIN resources r ON r.resource_id = a.resource_id
        WHERE a.disaster_id = %s AND r.type = %s
    """, (disaster_id, resource_type))
    total = cursor.fetchone()[0]
    conn.close()
    return total