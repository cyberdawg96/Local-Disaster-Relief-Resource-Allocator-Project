CREATE DATABASE IF NOT EXISTS disaster_relief_db;
USE disaster_relief_db;

CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin UNIQUE NOT NULL,
    password VARCHAR(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
    role ENUM('admin', 'coordinator', 'clerk') NOT NULL
);

INSERT IGNORE INTO users (username, password, role) VALUES
('admin', 'admin123', 'admin');

CREATE TABLE IF NOT EXISTS disasters (
    disaster_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    type VARCHAR(50),
    location_lat DOUBLE,
    location_lon DOUBLE,
    severity VARCHAR(20),
    report_date DATE,
    required_resource_type VARCHAR(50),
    required_quantity INT
);

CREATE TABLE IF NOT EXISTS resources (
    resource_id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(50),
    quantity INT,
    unit VARCHAR(20),
    current_location_lat DOUBLE,
    current_location_lon DOUBLE,
    status ENUM('available', 'reserved', 'dispatched') DEFAULT 'available'
);

CREATE TABLE IF NOT EXISTS coordinator_disaster_assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    coordinator_id INT,
    disaster_id INT,
    FOREIGN KEY (coordinator_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (disaster_id) REFERENCES disasters(disaster_id) ON DELETE CASCADE,
    UNIQUE(disaster_id)
);

CREATE TABLE IF NOT EXISTS allocations (
    allocation_id INT AUTO_INCREMENT PRIMARY KEY,
    resource_id INT,
    disaster_id INT,
    allocated_by INT,
    quantity_allocated INT,
    allocation_date DATE,
    delivery_status VARCHAR(50),
    FOREIGN KEY (resource_id) REFERENCES resources(resource_id) ON DELETE CASCADE,
    FOREIGN KEY (disaster_id) REFERENCES disasters(disaster_id) ON DELETE CASCADE,
    FOREIGN KEY (allocated_by) REFERENCES users(user_id) ON DELETE CASCADE
);