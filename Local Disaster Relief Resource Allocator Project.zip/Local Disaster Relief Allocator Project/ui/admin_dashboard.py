import tkinter as tk
from tkinter import ttk, messagebox
from db.queries import get_all_users, add_user, delete_user_by_username
from utils.csv_export import export_disasters_to_csv

class AdminDashboard:
    def __init__(self, root, user):
        self.root = root
        self.user = user
        self.root.title(f"Admin Dashboard - {user['username']}")

        window_width = 800
        window_height = 600

        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        x = (screen_width // 2) - (window_width // 2)
        y = (screen_height // 2) - (window_height // 2)

        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")
        self.root.configure(bg="#f6f7fb")

        self.style = ttk.Style(self.root)
        self._setup_style()
        self.setup_ui()

    def _setup_style(self):
        
        self.style.theme_use('clam')

        self.style.configure('TFrame', background="#f6f7fb")
        self.style.configure('TLabel', background="#f6f7fb", foreground="#1f1f1f", font=("Segoe UI", 10))
        self.style.configure('Header.TLabel', font=("Segoe UI", 16, 'bold'), background="#f6f7fb", foreground="#1f1f1f")

        self.style.configure('TButton', background="#a280f0", foreground="white",
                            font=("Segoe UI", 10, 'bold'))
        self.style.map('TButton',
                    background=[('active', '#7a5cc1')],
                    foreground=[('disabled', 'gray'), ('!disabled', "white")])

        self.style.configure('Treeview',
                            background="white",
                            fieldbackground="white",
                            foreground="black",
                            font=("Segoe UI", 10))
        self.style.configure('Treeview.Heading',
                            background="#a280f0",
                            foreground="white",
                            font=("Segoe UI", 10, 'bold'))

        self.style.map('Treeview',
                    background=[('selected', '#eceae6')], 
                    foreground=[('selected', 'black')])
        
        self.style.map('Treeview.Heading',
                    background=[('active', '#7a5cc1')],
                    foreground=[('active', 'white')])

        self.style.configure('CustomCombobox.TCombobox',
                             fieldbackground='white',
                             background='white',
                             foreground='black',
                             font=("Segoe UI", 10))
        self.style.map('CustomCombobox.TCombobox',
                       fieldbackground=[('readonly', 'white')],
                       selectbackground=[('readonly', 'white')],
                       selectforeground=[('readonly', 'black')])

    def setup_ui(self):
        title_lbl = ttk.Label(self.root, text="Admin Dashboard", style='Header.TLabel')
        title_lbl.pack(pady=(20, 10))

        table_labelframe = ttk.Labelframe(self.root, text="Registered Users")
        table_labelframe.pack(fill='both', expand=True, padx=20, pady=(0, 10))

        self.tree = ttk.Treeview(table_labelframe, columns=("Username", "Role"), show="headings", height=7)
        self.tree.heading("Username", text="Username")
        self.tree.heading("Role", text="Role")
        self.tree.column("Username", anchor='center', width=150)
        self.tree.column("Role", anchor='center', width=150)
        self.tree.pack(fill='both', expand=True, padx=10, pady=10)

        self.refresh_user_table()

        form_labelframe = ttk.Labelframe(self.root, text="Add New User")
        form_labelframe.pack(padx=20, pady=10, fill='x')

        tk.Label(form_labelframe, text="Username:", bg="#dddad4").grid(row=0, column=0, sticky='e', padx=5, pady=5)
        tk.Label(form_labelframe, text="Password:", bg="#dddad4").grid(row=1, column=0, sticky='e', padx=5, pady=5)
        tk.Label(form_labelframe, text="Role:", bg="#dddad4").grid(row=2, column=0, sticky='e', padx=5, pady=5)

        self.username_entry = ttk.Entry(form_labelframe, width=30)
        self.password_entry = ttk.Entry(form_labelframe, width=30, show='•')
        self.role_cb = ttk.Combobox(form_labelframe, values=["clerk", "coordinator"],
                                    width=28, state='readonly', style='CustomCombobox.TCombobox')

        self.username_entry.grid(row=0, column=1, padx=5, pady=5)
        self.password_entry.grid(row=1, column=1, padx=5, pady=5)
        self.role_cb.grid(row=2, column=1, padx=5, pady=5)

        add_btn = ttk.Button(form_labelframe, text="Add User", command=self.add_user)
        add_btn.grid(row=3, column=0, columnspan=2, pady=10)

        btn_frame = ttk.Frame(self.root)
        btn_frame.pack(pady=(0, 20))

        del_btn = ttk.Button(btn_frame, text="Delete Selected User", command=self.delete_user)
        export_btn = ttk.Button(btn_frame, text="Export Disasters to CSV", command=self.export_csv)

        del_btn.grid(row=0, column=0, padx=15, ipadx=10, ipady=2)
        export_btn.grid(row=0, column=1, padx=15, ipadx=10, ipady=2)


    def refresh_user_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        for user in get_all_users():
            self.tree.insert("", "end", values=(user["username"], user["role"]))

    def add_user(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        role = self.role_cb.get().strip()

        if not username or not password or not role:
            messagebox.showerror("Error", "All fields required.")
            return

        success = add_user(username, password, role)
        if success:
            self.refresh_user_table()
            messagebox.showinfo("Success", "User added.")
        else:
            messagebox.showerror("Error", "User creation failed. Cannot create another admin.")

    def delete_user(self):
        selected = self.tree.focus()
        if not selected:
            messagebox.showwarning("Warning", "Select a user to delete.")
            return
        username = self.tree.item(selected)['values'][0]
        if username == 'admin':
            messagebox.showerror("Error", "Cannot delete admin user.")
            return
        success = delete_user_by_username(username)
        if success:
            self.refresh_user_table()
            messagebox.showinfo("Deleted", f"User '{username}' deleted.")
        else:
            messagebox.showerror("Error", "Failed to delete user.")

    def export_csv(self):
        export_disasters_to_csv()
        messagebox.showinfo("Exported", "Disaster data exported to CSV with status.")