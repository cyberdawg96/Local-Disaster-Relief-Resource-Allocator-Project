import tkinter as tk
from tkinter import ttk, messagebox
from db.queries import (
    get_disasters_for_coordinator,
    get_available_resources,
    get_disaster_requirements,
    allocate_resource,
    is_disaster_fulfilled,
    get_allocated_sum
)
from utils.geospatial import calculate_distance
from datetime import date
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

class CoordinatorDashboard:
    def __init__(self, root, user):
        self.root = root
        self.user = user
        self.selected_disaster = None

        self.root.title(f"Coordinator Dashboard - {user['username']}")
        self.root.configure(bg="#f6f7fb")
        window_width = 1200
        window_height = 700

        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        x = (screen_width // 2) - (window_width // 2)
        y = (screen_height // 2) - (window_height // 2)

        self.root.geometry(f"{window_width}x{window_height}+{x}+{y}")

        self.style = ttk.Style(self.root)
        self._setup_style()
        self._build_ui()
        self._load_disasters()

    def _setup_style(self):
        s = self.style
        s.theme_use("clam")

        s.configure("TFrame", background="white")
        s.configure("TLabel", background="white", foreground="#1f1f1f", font=("Segoe UI", 10))
        s.configure("Header.TLabel", font=("Segoe UI", 14, 'bold'), background="white", foreground="#1f1f1f")

        s.configure("TButton", background="#a280f0", foreground="white", font=("Segoe UI", 10, 'bold'))
        s.map("TButton", background=[('active', "#7a5cc1")])

        s.configure("Treeview", background="white", fieldbackground="white",
                    foreground="#1f1f1f", font=("Segoe UI", 10))
        s.configure("Treeview.Heading", background="#a280f0", foreground="white",
                    font=("Segoe UI", 10, 'bold'))
        s.map("Treeview", background=[('selected', '#dcd6f7')], foreground=[('selected', 'black')])

        s.configure("Hover.TButton", background="#7a5cc1")

    def _build_ui(self):
        container = ttk.Frame(self.root)
        container.pack(fill='both', expand=True, padx=20, pady=20)

        top = ttk.Frame(container)
        top.pack(fill='both', expand=True)

        left = ttk.Labelframe(top, text="Assigned Disasters")
        left.pack(side='left', fill='both', expand=True, padx=10)
        self.disaster_tv = self._create_treeview(left, ["ID", "Name", "Severity", "Status"])
        self.disaster_tv.bind('<<TreeviewSelect>>', lambda e: self._on_select())

        center = ttk.Labelframe(top, text="Available Resources")
        center.pack(side='left', fill='both', expand=True, padx=10)
        self.resource_tv = self._create_treeview(center, ["ID", "Type", "Qty", "Distance"])

        right = ttk.Labelframe(top, text="Requirements")
        right.pack(side='left', fill='both', expand=True, padx=10)
        self.req_txt = tk.Text(right, bg="white", fg="#1f1f1f", insertbackground="#1f1f1f",
                               font=("Segoe UI", 10), height=12, width=35, state='disabled')
        self.req_txt.pack(fill='both', expand=True, padx=10, pady=10)

        bottom = ttk.Frame(container)
        bottom.pack(fill='x', pady=15)

        ttk.Label(bottom, text="Allocate Quantity:").grid(row=0, column=0, padx=5)
        self.qty_entry = ttk.Entry(bottom, width=10)
        self.qty_entry.grid(row=0, column=1, padx=5)

        alloc = ttk.Button(bottom, text="Allocate", command=self._allocate)
        alloc.grid(row=0, column=2, padx=10, ipadx=10)
        self._hover(alloc)

        chart = ttk.Button(bottom, text="Show Resource Chart", command=self._show_chart)
        chart.grid(row=0, column=3, padx=10, ipadx=10)
        self._hover(chart)

    def _create_treeview(self, parent, columns):
        frame = ttk.Frame(parent)
        frame.pack(fill='both', expand=True, padx=10, pady=10)
        tv = ttk.Treeview(frame, columns=columns, show='headings', height=8)
        for col in columns:
            tv.heading(col, text=col)
            tv.column(col, anchor='center', width=120)
        scrollbar = ttk.Scrollbar(frame, orient='vertical', command=tv.yview)
        tv.configure(yscroll=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        tv.pack(fill='both', expand=True)
        return tv

    def _hover(self, btn):
        btn.bind('<Enter>', lambda e: btn.config(style='Hover.TButton'))
        btn.bind('<Leave>', lambda e: btn.config(style='TButton'))

    def _load_disasters(self):
        self.disaster_tv.delete(*self.disaster_tv.get_children())
        for d in get_disasters_for_coordinator(self.user['user_id']):
            if is_disaster_fulfilled(d['disaster_id']):
                continue
            self.disaster_tv.insert('', 'end', values=(d['disaster_id'], d['name'], d['severity'], 'pending'))

    def _on_select(self):
        sel = self.disaster_tv.focus()
        if not sel:
            return
        d_id = int(self.disaster_tv.item(sel, 'values')[0])
        disaster = next((x for x in get_disasters_for_coordinator(self.user['user_id']) if x['disaster_id'] == d_id), None)
        self.selected_disaster = d_id
        self.disaster_lat = disaster['location_lat']
        self.disaster_lon = disaster['location_lon']
        self._load_requirements()
        self._load_resources()

    def _load_requirements(self):
        self.req_txt.config(state='normal')
        self.req_txt.delete('1.0', tk.END)
        req = get_disaster_requirements(self.selected_disaster)
        if not req:
            self.req_txt.insert(tk.END, "No requirements.")
            self.req_txt.config(state='disabled')
            return
        allocated = get_allocated_sum(self.selected_disaster, req['required_resource_type'])
        remaining = req['required_quantity'] - allocated
        if remaining <= 0:
            self.req_txt.insert(tk.END, "Requirement fulfilled.")
        else:
            self.req_txt.insert(tk.END,
                                f"Resource: {req['required_resource_type']}\n"
                                f"Required: {req['required_quantity']}\n"
                                f"Allocated: {allocated}\n"
                                f"Remaining: {remaining}\n")
        self.req_txt.config(state='disabled')
        self.current_remaining = max(0, remaining)

    def _load_resources(self):
        self.resource_tv.delete(*self.resource_tv.get_children())
        if self.current_remaining <= 0:
            return
        req_type = get_disaster_requirements(self.selected_disaster)['required_resource_type'].lower()
        filtered_resources = []
        for res in get_available_resources():
            if res['type'].lower() != req_type:
                continue
            dist = calculate_distance(self.disaster_lat, self.disaster_lon,
                                      res['current_location_lat'], res['current_location_lon'])
            filtered_resources.append({
                'resource_id': res['resource_id'],
                'type': res['type'],
                'quantity': res['quantity'],
                'distance': dist
            })
        sorted_resources = sorted(filtered_resources, key=lambda r: (r['distance'], r['quantity']))
        for res in sorted_resources:
            self.resource_tv.insert('', 'end', values=(res['resource_id'], res['type'],
                                                       res['quantity'], f"{res['distance']:.2f} km"))

    def _allocate(self):
        sel = self.resource_tv.focus()
        if not sel:
            return messagebox.showerror("Error", "Select a resource.")
        try:
            qty = int(self.qty_entry.get())
        except ValueError:
            return messagebox.showerror("Error", "Enter a valid quantity.")
        if qty > self.current_remaining:
            return messagebox.showerror("Error", "Cannot allocate more than required.")
        res_id = int(self.resource_tv.item(sel, 'values')[0])
        success = allocate_resource(
            resource_id=res_id,
            disaster_id=self.selected_disaster,
            user_id=self.user['user_id'],
            quantity_allocated=qty,
            date_allocated=date.today().strftime('%Y-%m-%d')
        )
        if success:
            messagebox.showinfo("Success", "Resource allocated.")
            if is_disaster_fulfilled(self.selected_disaster):
                self._load_disasters()
                self.req_txt.config(state='normal')
                self.req_txt.delete('1.0', tk.END)
                self.req_txt.config(state='disabled')
            else:
                self._load_requirements()
            self._load_resources()
        else:
            messagebox.showerror("Error", "Allocation failed.")

    def _show_chart(self):
        data = get_available_resources()
        if not data:
            return messagebox.showerror("Error", "No resources to chart.")
        counts = {}
        for r in data:
            counts[r['type']] = counts.get(r['type'], 0) + r['quantity']
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(counts.keys(), counts.values(), color="#8B5CF6")
        ax.set_title("Available Resources")
        ax.set_ylabel("Quantity")

        win = tk.Toplevel(self.root)
        win.title("Resource Chart")
        win.geometry("600x400")
        canvas = FigureCanvasTkAgg(fig, master=win)
        canvas.draw()
        canvas.get_tk_widget().pack(fill='both', expand=True)