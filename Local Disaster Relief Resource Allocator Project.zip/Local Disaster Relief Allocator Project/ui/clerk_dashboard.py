import tkinter as tk
from tkinter import ttk, messagebox
from db.queries import (
    add_disaster, add_resource,
    get_all_disasters, get_all_coordinators, get_disaster_assigned_count,
    assign_disaster_to_coordinator
)

class ClerkDashboard:
    def __init__(self, root, user):
        self.root = root
        self.user = user
        self.root.title(f"Clerk Dashboard - {user['username']}")
        self.root.configure(bg="#f6f7fb")
        self.style = ttk.Style(self.root)
        self._setup_style()
        self.setup_ui()

        self.center_window()

    def center_window(self):
        self.root.update_idletasks()  

        width = self.root.winfo_width()
        height = self.root.winfo_height()

        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        x = (screen_width // 2) - (width // 2)
        y = (screen_height // 2) - (height // 2)

        self.root.geometry(f"{width}x{height}+{x}+{y}")

    def _setup_style(self):
        self.style.theme_use("clam")
        self.style.configure('TFrame', background="#f6f7fb")
        self.style.configure('TLabel', background="#f6f7fb", foreground="#1f1f1f", font=("Segoe UI", 10))
        self.style.configure('Header.TLabel', font=("Segoe UI", 16, 'bold'), background="#f6f7fb", foreground="#1f1f1f")

        self.style.configure('TButton', background="#a280f0", foreground="#ffffff",
                             font=("Segoe UI", 10, 'bold'))
        self.style.map('TButton',
                       background=[('active', '#7a5cc1')],
                       foreground=[('disabled', 'gray'), ('!disabled', "#ffffff")])

        self.style.configure('TEntry', font=("Segoe UI", 10))
        self.style.configure('TNotebook.Tab', background="#a280f0", foreground="#ffffff",
                             font=("Segoe UI", 10, 'bold'))
        self.style.map('TNotebook.Tab', background=[('selected', '#7a5cc1')])

    def setup_ui(self):
        ttk.Label(self.root, text="Clerk Dashboard", style='Header.TLabel').pack(pady=(20, 10))

        tabs = ttk.Notebook(self.root)
        tabs.pack(fill="both", expand=True, padx=20, pady=10)

        self.add_disaster_tab(tabs)
        self.add_resource_tab(tabs)
        self.assign_disaster_tab(tabs)

    def add_disaster_tab(self, tabs):
        frame = ttk.Frame(tabs)
        tabs.add(frame, text="Add Disaster")

        lf = ttk.Labelframe(frame, text="Disaster Information")
        lf.pack(padx=20, pady=20, fill='x')

        labels = [
            "Name", "Type", "Severity",
            "Latitude", "Longitude", "Date (YYYY-MM-DD)",
            "Required Resource Type", "Required Quantity"
        ]
        self.d_entries = {}
        for i, label in enumerate(labels):
            ttk.Label(lf, text=label).grid(row=i, column=0, sticky="e", padx=5, pady=5)
            entry = ttk.Entry(lf, width=30)
            entry.grid(row=i, column=1, padx=5, pady=5)
            self.d_entries[label] = entry

        btn = ttk.Button(lf, text="Add Disaster", command=self.add_disaster)
        btn.grid(row=len(labels), column=0, columnspan=2, pady=15, ipadx=10)

    def add_disaster(self):
        try:
            name = self.d_entries["Name"].get().strip()
            dtype = self.d_entries["Type"].get().strip()
            severity = self.d_entries["Severity"].get().strip()
            lat = float(self.d_entries["Latitude"].get())
            lon = float(self.d_entries["Longitude"].get())
            report_date = self.d_entries["Date (YYYY-MM-DD)"].get().strip()
            resource_type = self.d_entries["Required Resource Type"].get().strip()
            resource_quantity = int(self.d_entries["Required Quantity"].get())

            success = add_disaster(name, dtype, severity, lat, lon, report_date, resource_type, resource_quantity)

            if success:
                messagebox.showinfo("Success", "Disaster added successfully.")
                self.load_disaster_info()
            else:
                messagebox.showerror("Error", "Failed to add disaster.")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")

    def add_resource_tab(self, tabs):
        frame = ttk.Frame(tabs)
        tabs.add(frame, text="Add Resource")

        lf = ttk.Labelframe(frame, text="Resource Information")
        lf.pack(padx=20, pady=20, fill='x')

        labels = ["Type", "Quantity", "Unit", "Latitude", "Longitude"]
        self.r_entries = {}
        for i, label in enumerate(labels):
            ttk.Label(lf, text=label).grid(row=i, column=0, sticky="e", padx=5, pady=5)
            entry = ttk.Entry(lf, width=30)
            entry.grid(row=i, column=1, padx=5, pady=5)
            self.r_entries[label] = entry

        btn = ttk.Button(lf, text="Add Resource", command=self.add_resource)
        btn.grid(row=len(labels), column=0, columnspan=2, pady=15, ipadx=10)

    def add_resource(self):
        try:
            data = {
                "type": self.r_entries["Type"].get().strip(),
                "quantity": int(self.r_entries["Quantity"].get()),
                "unit": self.r_entries["Unit"].get().strip(),
                "lat": float(self.r_entries["Latitude"].get()),
                "lon": float(self.r_entries["Longitude"].get())
            }
            if add_resource(**data):
                messagebox.showinfo("Success", "Resource added.")
            else:
                messagebox.showerror("Error", "Failed to add resource.")
        except Exception:
            messagebox.showerror("Error", "Invalid input. Check fields.")

    def assign_disaster_tab(self, tabs):
        frame = ttk.Frame(tabs)
        tabs.add(frame, text="Assign Disaster")

        lists_frame = ttk.Labelframe(frame, text="Disasters and Coordinators")
        lists_frame.pack(fill='both', expand=True, padx=20, pady=10)

        ttk.Label(lists_frame, text="Existing Disasters:").grid(row=0, column=0, sticky='w', padx=5)
        self.disaster_list = tk.Text(lists_frame, height=8, width=50, bg="white", fg="black",
                                     insertbackground="black", font=("Segoe UI", 10))
        self.disaster_list.grid(row=1, column=0, padx=5, pady=5)

        ttk.Label(lists_frame, text="Available Coordinators:").grid(row=0, column=1, sticky='w', padx=5)
        self.coordinator_list = tk.Text(lists_frame, height=8, width=50, bg="white", fg="black",
                                        insertbackground="black", font=("Segoe UI", 10))
        self.coordinator_list.grid(row=1, column=1, padx=5, pady=5)

        form_frame = ttk.Labelframe(frame, text="Assign Details")
        form_frame.pack(padx=20, pady=10, fill='x')

        ttk.Label(form_frame, text="Disaster ID:").grid(row=0, column=0, sticky='e', padx=5, pady=5)
        ttk.Label(form_frame, text="Coordinator ID:").grid(row=1, column=0, sticky='e', padx=5, pady=5)

        self.disaster_id_entry = ttk.Entry(form_frame, width=30)
        self.coordinator_id_entry = ttk.Entry(form_frame, width=30)
        self.disaster_id_entry.grid(row=0, column=1, padx=5, pady=5)
        self.coordinator_id_entry.grid(row=1, column=1, padx=5, pady=5)

        btn = ttk.Button(form_frame, text="Assign", command=self.assign_disaster)
        btn.grid(row=2, column=0, columnspan=2, pady=10, ipadx=10)

        self.load_disaster_info()

    def load_disaster_info(self):
        self.disaster_list.config(state='normal')
        self.coordinator_list.config(state='normal')

        self.disaster_list.delete("1.0", tk.END)
        self.coordinator_list.delete("1.0", tk.END)

        disasters = get_all_disasters()
        for d in disasters:
            status = "fulfilled" if d.get("fulfilled") else "pending"
            self.disaster_list.insert(tk.END, f"ID: {d['disaster_id']} | {d['name']} | {d['type']} | Status: {status}\n")

        coords = get_all_coordinators()
        for c in coords:
            count = get_disaster_assigned_count(c["user_id"])
            self.coordinator_list.insert(tk.END, f"ID: {c['user_id']} | {c['username']} | Assigned: {count}\n")

        self.disaster_list.config(state='disabled')
        self.coordinator_list.config(state='disabled')

    def assign_disaster(self):
        try:
            disaster_id = int(self.disaster_id_entry.get())
            coordinator_id = int(self.coordinator_id_entry.get())

            valid_d = [d['disaster_id'] for d in get_all_disasters()]
            valid_c = [c['user_id'] for c in get_all_coordinators()]
            if disaster_id not in valid_d:
                messagebox.showerror("Error", "Disaster ID not found.")
                return
            if coordinator_id not in valid_c:
                messagebox.showerror("Error", "Coordinator ID not found.")
                return

            if assign_disaster_to_coordinator(disaster_id, coordinator_id):
                messagebox.showinfo("Success", "Assigned successfully.")
                self.load_disaster_info()
            else:
                messagebox.showerror("Error", "Assignment failed.")
        except Exception:
            messagebox.showerror("Error", "Invalid input.")